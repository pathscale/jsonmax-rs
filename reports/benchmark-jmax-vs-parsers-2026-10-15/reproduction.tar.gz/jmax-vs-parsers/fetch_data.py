import pathlib, urllib.request, json, hashlib
p=pathlib.Path('/tmp/jmax-bench-data');p.mkdir(parents=True,exist_ok=True)
manifest=json.loads((p/'manifest.json').read_text())
for row in manifest:
 if row['url'].startswith('https://'):
  data=urllib.request.urlopen(row['url']).read()
 else:
  data=(p/row['name']).read_bytes()
 assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'],row['name']
 json.loads(data);(p/row['name']).write_bytes(data)
print('All six fixture sizes, SHA-256 hashes, and JSON syntax verified.')
