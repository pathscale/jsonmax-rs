import json, pathlib, hashlib
p=pathlib.Path('/tmp/jmax-bench-data')
v={'batch_id':'batch-2026-10-15-0042','tenant':'acme-東京','schema_version':3,'request_count':0,'accepted':True,'records':[]}
i=0
while len(json.dumps(v,ensure_ascii=False,separators=(',',':')).encode())<102400:
 v['records'].append({'request_id':f'req-{i:06d}','endpoint':'/v1/orders' if i%2 else '/v1/catalog/items','method':'POST' if i%2 else 'GET','schema':{'name':'CreateOrder' if i%2 else 'ListItems','version':3,'required':['customer_id','items'],'additionalProperties':False},'request':{'customer_id':10000+i,'currency':'USD','items':[{'sku':f'SKU-{i:05d}','quantity':1+i%8,'unit_price':19.95+i/100}],'notes':'Deliver to 東京 / Montréal 🛒\nDoor code: "42"; path C:\\orders\\pending\t✓'},'response':{'status':201 if i%2 else 200,'duration_ms':round(0.5+i/17,6),'body':{'id':900000+i,'state':'accepted','tags':['api','json','café'],'errors':[]}},'trace':{'sampled':i%3==0,'region':'ap-southeast-1','retry_count':i%3}})
 i+=1;v['request_count']=i
b=json.dumps(v,ensure_ascii=False,separators=(',',':')).encode();(p/'endpoint_batch.json').write_bytes(b)
m=json.loads((p/'manifest.json').read_text());m=[x for x in m if x['name']!='endpoint_batch.json'];m.append(dict(name='endpoint_batch.json',bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),url='Generated deterministically by /tmp/jmax-vs-parsers/generate_endpoint.py; not a standard corpus',records=i));(p/'manifest.json').write_text(json.dumps(m,indent=2));print(m[-1])
