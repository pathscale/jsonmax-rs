from pathlib import Path
import tarfile,hashlib
p=Path('/tmp/jmax-vs-parsers');art=Path('/Users/revenge/code/jsonmax-rs/reports/benchmark-jmax-vs-parsers-2026-10-15')
names=['Cargo.toml','Cargo.lock','frozen/Cargo.toml','frozen/Cargo.lock','frozen/src','src','source-snapshot','generate_endpoint.py','fetch_data.py','run_repeated.py','write_report.py','package_artifacts.py','compile-fixes.patch','source-manifest.json','source-revision.txt','environment.json','metadata.json','frozen-metadata.json','local-dependencies.json','corpus-details.json','validation-matrix.json','preflight.log','built-in-frozen.txt','built-in-frozen.log','system-load.jsonl','run1.jsonl','run2.jsonl','run3.jsonl','run1.log','run2.log','run3.log','report-generation.log']
def filtr(info):
 return None if 'target' in Path(info.name).parts or '.git' in Path(info.name).parts else info
with tarfile.open(art/'reproduction.tar.gz','w:gz',compresslevel=9) as tar:
 for name in names:
  f=p/name
  if f.exists() or f.is_symlink():tar.add(f,arcname='jmax-vs-parsers/'+name,filter=filtr)
 for f in Path('/tmp/jmax-bench-data').iterdir():
  if f.is_file():tar.add(f,arcname='jmax-bench-data/'+f.name)
 for f in map(Path,['/tmp/jmax-workspace-build.log','/tmp/jmax-live-checkout-final-build.log','/tmp/jmax-frozen-build.log','/tmp/jmax-built-in-bench.txt','/tmp/jmax-built-in-bench.log']):
  if f.exists():tar.add(f,arcname='jmax-vs-parsers/build-logs/'+f.name)
checks={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in art.iterdir() if f.is_file() and f.name!='SHA256SUMS'}
(art/'SHA256SUMS').write_text(''.join(f'{sha}  {name}\n' for name,sha in sorted(checks.items())))
print('Packaged source, harness, fixtures, raw samples, and logs; refreshed SHA256SUMS.')
